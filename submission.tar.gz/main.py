from __future__ import annotations

import dataclasses
import os
import sys
from dataclasses import dataclass, replace

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _HERE = os.getcwd()
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import torch
from torch import Tensor

from orbit_lite.constants import CENTER
from orbit_lite.geometry import fleet_speed
from orbit_lite.intercept_aim import intercept_angle
from orbit_lite.movement import MovementConfig, PlanetMovement
from orbit_lite.movement_step import (
    apply_private_planned_launches,
    concat_launch_entries,
    disambiguate_duplicate_launches,
    ensure_planet_movement,
    infer_planned_launches_from_entries,
)
from orbit_lite.obs import parse_obs
from orbit_lite.distance_cache import build_distance_cache
from orbit_lite.garrison_launch import precompute_flow_baseline
from orbit_lite.planner_core import (
    _candidate_indices,
    _empty_entries,
    _greedy_select,
    _plan_regroup,
    build_target_shortlist,
    capture_floor,
    empty_action_row,
    entries_to_sparse_payload,
    largest_initial_player_count,
    make_launch_set,
    reachable_mask,
    reinforcement_timing_factor,
    safe_drain,
    score_candidates,
)
from orbit_lite.adapter import single_obs_to_tensor, sparse_action_row_to_moves

TOTAL_STEPS = 500


# ---------------------------------------------------------------------------
# Config – extended with dynamic knobs + defense/geometry + comet params
#          + new spatial strategy params
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ProducerLiteConfig:
    horizon: int = 18
    max_sources_per_lane: int = 12
    max_offensive_targets: int = 12
    max_defensive_targets: int = 6
    max_waves_per_turn: int = 6
    roi_threshold: float = 1.35
    min_ships_to_launch: float = 3.0
    reinforce_size_beta: float = 2.2
    reinforce_eta_free: float = 3.0
    reinforce_eta_scale: float = 12.0
    enable_regroup: bool = True
    max_regroup_time: float = 7.0
    regroup_pressure_delta_min: float = 0.20
    max_regroup_sources_per_lane: int = 6
    max_regroup_targets_per_source: int = 7
    regroup_pressure_norm: str = "none"
    regroup_time_penalty_weight: float = 1e-3
    # Dynamic scaling
    min_roi: float = 1.10
    max_roi: float = 1.45
    horizon_min: int = 8
    horizon_max: int = 24
    beta_min: float = 1.2
    beta_max: float = 3.5
    # Proactive defense
    defense_threat_horizon: float = 14.0
    defense_min_intercept_margin: float = 1.05
    defense_max_waves: int = 3
    # Orbital geometry
    geometry_weight: float = 0.35
    # Production snowball
    prod_rush_steps: int = 120
    prod_rush_top_k: int = 3
    prod_rush_roi_discount: float = 0.60
    # Comet hunting
    comet_score_multiplier: float = 2.0
    comet_movement_threshold: float = 0.5
    # ---- NEW: Nearest/Furthest wave split ----
    near_wave_fraction: float = 0.65   # fraction of W waves allocated to nearest targets
    # ---- NEW: Shrinking ring conquest ----
    enable_ring_conquest: bool = True
    ring_inner_boost: float = 2.5      # score multiplier for targets inside conquest ring
    ring_outer_penalty: float = 0.4    # score multiplier for targets outside ring
    ring_min_radius_frac: float = 0.15 # ring never shrinks below this fraction of map radius
    # ---- NEW: KNN source selection ----
    knn_sources_per_target: int = 3    # how many nearest owned planets to consider per target
    # ---- NEW: Committed-fleet penalty ----
    committed_fleet_penalty: float = 0.25  # score multiplier for already-targeted planets
    # ---- NEW: Border planet defense boost ----
    border_boost: float = 1.6          # score bonus multiplier for planets on the enemy-facing border
    border_radius_frac: float = 0.30   # fraction of map radius that defines "border"
    # ---- NEW: Multi-size and Multi-source ----
    size_multipliers: tuple[float, ...] = (1.0,)
    max_contributors_per_wave: int = 1


# ---------------------------------------------------------------------------
# Strength proxy
# ---------------------------------------------------------------------------

def _owner_strength(obs, prod: Tensor, player_count: int) -> Tensor:
    """Vectorized owner strength: prod + 2.5% ships."""
    dtype = prod.dtype
    device = prod.device
    strength = torch.zeros(int(player_count), dtype=dtype, device=device)
    owner = obs.owner_abs.to(device=device).long()
    alive = obs.alive.to(device=device)
    # Vectorized sum using scatter_add_ to avoid O(A*P) Python loops.
    planet_score = prod.to(dtype) + 0.025 * obs.ships.to(dtype)
    valid = alive & (owner >= 0)
    strength.scatter_add_(0, owner[valid], planet_score[valid])
    return strength


# ---------------------------------------------------------------------------
# Orbital centrality
# ---------------------------------------------------------------------------

def _orbital_centrality(obs, cache) -> Tensor:
    """Vectorized orbital centrality using matrix-vector product."""
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    if P <= 1:
        return torch.ones(P, device=device, dtype=dtype)
    # Bolt: Use matrix-vector product to avoid redundant masks and clones.
    d0 = cache.cross_dist[0].to(dtype)
    alive = obs.alive.to(dtype)
    total_dist = torch.mv(d0, alive)
    total_dist = torch.where(obs.alive, total_dist, torch.zeros_like(total_dist))
    n_alive = alive.sum().clamp(min=1.0)
    return n_alive / (total_dist + n_alive)


# ---------------------------------------------------------------------------
# NEW: Adaptive distance scale
# Replaces the hardcoded /15.0 — scales with the actual median pairwise distance
# so the penalty is proportional to the map rather than a magic constant.
# ---------------------------------------------------------------------------

def _adaptive_distance_scale(dist: Tensor, cache, obs) -> Tensor:
    """Return a per-candidate distance multiplier in (0, 1]."""
    P = int(obs.P)
    alive = obs.alive
    if P > 1 and bool(alive.any()):
        d0 = cache.cross_dist[0]
        alive_d = d0[alive][:, alive]
        median_dist = float(alive_d.float().median().item())
    else:
        median_dist = 15.0
    ref = max(median_dist * 0.5, 1.0)
    return 1.0 / (1.0 + dist / ref)


# ---------------------------------------------------------------------------
# NEW: Shrinking ring conquest
# Computes the current conquest ring radius and returns per-planet multipliers:
#   - inside ring  → ring_inner_boost  (prioritise completing the filled circle)
#   - outside ring → ring_outer_penalty (deprioritise overextension)
# The ring is centred on the production-weighted centroid of owned planets
# and shrinks linearly as the game progresses.
# ---------------------------------------------------------------------------

def _ring_conquest_multiplier(
    *,
    obs,
    target_idx: Tensor,
    cache,
    config: ProducerLiteConfig,
    step: int,
) -> Tensor:
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    ones = torch.ones(int(target_idx.shape[0]), dtype=dtype, device=device)

    if not config.enable_ring_conquest:
        return ones

    owned = obs.owned & obs.alive
    if not bool(owned.any()):
        return ones

    pos = torch.stack([obs.x, obs.y], dim=1).to(dtype)
    prod_v = obs.ships.to(dtype)
    w = prod_v[owned]
    centre = (pos[owned] * w.unsqueeze(1)).sum(0) / (w.sum() + 1e-6)

    alive_pos = pos[obs.alive]
    dists_from_centre = torch.norm(alive_pos - centre, dim=1)
    map_radius = float(dists_from_centre.max().item()) if dists_from_centre.numel() > 0 else 1.0

    # التعديل هنا: الدائرة تبدأ واسعة جداً في أول 100 خطوة
    if step < 100:
        dynamic_min_frac = 0.6  # توسع
    else:
        dynamic_min_frac = float(config.ring_min_radius_frac) # انكماش

    min_r = dynamic_min_frac * map_radius
    t = min(float(step) / TOTAL_STEPS, 1.0)
    ring_radius = map_radius * (1.0 - t) + min_r * t

    tgt_abs = target_idx.clamp(0, P - 1)
    tgt_pos = pos[tgt_abs]
    tgt_dist = torch.norm(tgt_pos - centre.unsqueeze(0), dim=1)

    inside = tgt_dist <= ring_radius
    mult = torch.where(
        inside,
        torch.full_like(tgt_dist, float(config.ring_inner_boost)),
        torch.full_like(tgt_dist, float(config.ring_outer_penalty)),
    )
    return mult


# ---------------------------------------------------------------------------
# NEW: KNN source selection per target
# Instead of a single global source pool, for each target we pick the
# knn_sources_per_target nearest owned planets as candidate sources.
# Returns supplementary source indices merged with the original pool.
# ---------------------------------------------------------------------------

def _knn_sources_for_targets(
    *,
    obs,
    target_idx: Tensor,
    cache,
    config: ProducerLiteConfig,
) -> Tensor:
    """Vectorized KNN source selection per target (Pulse)."""
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    K = int(config.knn_sources_per_target)
    owned_mask = obs.owned & obs.alive & (obs.ships >= float(config.min_ships_to_launch))
    n_owned = int(owned_mask.sum().item())
    if n_owned == 0 or K <= 0 or target_idx.numel() == 0:
        return torch.zeros(0, dtype=torch.long, device=device)
    d0 = cache.cross_dist[0].to(dtype)
    tgt_abs = target_idx.clamp(0, P - 1)
    d_tp = d0[tgt_abs]
    invalid_mask = (~owned_mask).view(1, P).expand(tgt_abs.shape[0], P)
    self_mask = torch.eye(P, device=device, dtype=torch.bool)[tgt_abs]
    d_tp = torch.where(invalid_mask | self_mask, torch.tensor(1e9, device=device, dtype=dtype), d_tp)
    k = min(K, n_owned)
    nearest = torch.topk(-d_tp, k, dim=1).indices
    return nearest.view(-1).unique()


# ---------------------------------------------------------------------------
# NEW: Committed-fleet penalty
# Targets that already have fleets inbound (tracked in memory) get a score
# penalty to avoid double-sending ships wastefully.
# ---------------------------------------------------------------------------

def _committed_fleet_penalty_mask(
    *,
    obs,
    target_idx: Tensor,
    memory,
    config: ProducerLiteConfig,
) -> Tensor:
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    ones = torch.ones(int(target_idx.shape[0]), dtype=dtype, device=device)

    committed = getattr(memory, "committed_targets", None)
    if committed is None or committed.numel() == 0:
        return ones

    tgt_abs = target_idx.clamp(0, P - 1)
    is_committed = torch.isin(tgt_abs, committed.to(device=device))

    # التعديل: فحص هل العدو أرسل تعزيزات للهدف (قوة الكوكب زادت بشكل مفاجئ)
    last_ships = getattr(memory, "last_target_ships", None)
    if last_ships is not None:
        current_tgt_ships = obs.ships[tgt_abs].to(device=device)
        old_tgt_ships = last_ships[tgt_abs].to(device=device)
        # إذا زادت سفن الهدف بأكثر من 30%، ألغِ العقوبة واسمح بهجوم ثاني!
        sudden_reinforcement = current_tgt_ships > (old_tgt_ships * 1.3)
        is_committed = is_committed & (~sudden_reinforcement)

    penalty = float(config.committed_fleet_penalty)
    return torch.where(is_committed, torch.full_like(ones, penalty), ones)


# ---------------------------------------------------------------------------
# NEW: Border planet defense boost
# Planets on the frontier facing enemy territory get proactive defense weight.
# "Border" = owned planets within border_radius_frac * map_radius of the
# nearest enemy planet.
# ---------------------------------------------------------------------------

def _border_defense_boost(
    *,
    obs,
    cache,
    config: ProducerLiteConfig,
) -> Tensor:
    """Returns a per-planet multiplier (>1 for border planets, 1 elsewhere)."""
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    boost_vec = torch.ones(P, dtype=dtype, device=device)

    pid = int(obs.player_id)
    owned = obs.owned & obs.alive
    enemy = obs.alive & (obs.owner_abs >= 0) & (obs.owner_abs != pid)

    if not bool(owned.any()) or not bool(enemy.any()):
        return boost_vec

    d0 = cache.cross_dist[0].to(dtype)  # [P, P]

    # Map radius from alive centroid
    pos = torch.stack([obs.x, obs.y], dim=1).to(dtype)
    alive_pos = pos[obs.alive]
    if alive_pos.shape[0] < 2:
        return boost_vec
    centre = alive_pos.mean(0)
    map_radius = float(torch.norm(alive_pos - centre, dim=1).max().item())
    border_dist = float(config.border_radius_frac) * map_radius

    # For each owned planet, minimum distance to any enemy planet
    d_owned_enemy = d0[owned][:, enemy]          # [n_owned, n_enemy]
    min_enemy_dist = d_owned_enemy.min(dim=1).values  # [n_owned]

    owned_idx = owned.nonzero(as_tuple=False).squeeze(1)
    is_border = min_enemy_dist <= border_dist
    boost_vec[owned_idx[is_border]] = float(config.border_boost)
    return boost_vec


# ---------------------------------------------------------------------------
# Proactive defense
# ---------------------------------------------------------------------------

def _build_defense_entries(
    *,
    status: PlanetGarrisonStatus,
    obs,
    cache,
    prod: Tensor,
    config: ProducerLiteConfig,
    player_count: int,
    border_boost_vec: Tensor,
    intel_def: Tensor,
):
    """Proactive defense entries; optimized to reuse status + prod and avoid syncs."""
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    pid = int(obs.player_id)
    if P == 0: return _empty_entries(device, dtype)
    owned = obs.owned & obs.alive
    if not bool(owned.any()): return _empty_entries(device, dtype)
    H_val = status.ships.shape[-1] - 1
    if H_val <= 0: return _empty_entries(device, dtype)
    ships_at_H = status.ships[:, -1]
    current_ships = obs.ships.to(dtype)
    border_threat_scale = border_boost_vec.clamp(max=2.0)
    effective_ships = (ships_at_H / border_threat_scale) * intel_def
    threatened = owned & (effective_ships < 0)
    doomed = threatened & (effective_ships < -3.0 * current_ships)
    savable = threatened & (~doomed)
    all_entries = []
    if bool(doomed.any()):
        doomed_indices = doomed.nonzero(as_tuple=False).squeeze(1)
        safe_planets = owned & (~threatened)
        if bool(safe_planets.any()):
            safe_idx = safe_planets.nonzero(as_tuple=False).squeeze(1)
            d0 = cache.cross_dist[0].to(dtype)
            can_evac = current_ships[doomed_indices] >= 1.0
            if can_evac.any():
                evac_indices = doomed_indices[can_evac]
                dists = d0[evac_indices][:, safe_idx]
                best_safe_local = dists.argmin(dim=1)
                best_safe_global = safe_idx[best_safe_local]
                M_evac = evac_indices.shape[0]
                src_t = evac_indices.view(M_evac, 1)
                tgt_t = best_safe_global.view(M_evac, 1)
                send_t = current_ships[evac_indices].view(M_evac, 1)
                eta_t = torch.ones((M_evac, 1), dtype=dtype, device=device)
                valid_t = torch.ones((M_evac, 1), dtype=torch.bool, device=device)
                all_entries.append(make_launch_set(source_slots=src_t, target_slots=tgt_t, ships=send_t, eta=eta_t, valid=valid_t, player_id=pid))
    # Available ships tracked through defense allocation
    current_budget = current_ships.clone()
    # Mark evacuate sources as used
    if all_entries:
        for entry in all_entries:
            current_budget.scatter_add_(0, entry.source_slots.view(-1), -entry.ships.view(-1))

    if bool(savable.any()):
        savable_indices = savable.nonzero(as_tuple=False).squeeze(1)
        high_value = (prod[savable_indices] >= 0.5) | (current_ships[savable_indices] >= 20.0)
        tgt_indices = savable_indices[high_value]
        if bool(tgt_indices.any()):
            src_indices = owned.nonzero(as_tuple=False).squeeze(1)
            d0 = cache.cross_dist[0].to(dtype)
            available_ships = current_budget
            ships_at_H_cpu = ships_at_H.cpu()
            waves_launched, max_waves = 0, int(config.defense_max_waves)
            margin, min_launch = float(config.defense_min_intercept_margin), float(config.min_ships_to_launch)
            for tgt in tgt_indices.tolist():
                if waves_launched >= max_waves: break
                deficit = float(-ships_at_H_cpu[tgt])
                need = deficit * margin
                if need <= 0: continue
                dists = d0[src_indices, tgt]
                speeds = fleet_speed(available_ships[src_indices].clamp(min=1.0))
                etas = (dists / speeds.clamp(min=1e-6)).ceil()
                valid_src_mask = (etas <= float(H_val)) & (src_indices != tgt) & (~doomed[src_indices]) & (available_ships[src_indices] > min_launch)
                if not valid_src_mask.any(): continue
                v_src_idx = src_indices[valid_src_mask]
                sorted_indices = torch.argsort(dists[valid_src_mask])
                contributed_ships = 0.0
                available_ships_cpu = available_ships.cpu()
                for idx in sorted_indices.tolist():
                    s_idx = int(v_src_idx[idx].item())
                    s_eta = float(etas[valid_src_mask][idx].item())
                    s_give = min(float(available_ships_cpu[s_idx]) * 0.5, need - contributed_ships)
                    if s_give >= min_launch:
                        src_t, tgt_t = torch.tensor([[s_idx]], device=device), torch.tensor([[tgt]], device=device)
                        send_t, eta_t = torch.tensor([[s_give]], device=device, dtype=dtype), torch.tensor([[s_eta]], device=device, dtype=dtype)
                        all_entries.append(make_launch_set(source_slots=src_t, target_slots=tgt_t, ships=send_t, eta=eta_t, valid=torch.tensor([[True]], device=device), player_id=pid))
                        contributed_ships += s_give
                        available_ships[s_idx] -= s_give
                        available_ships_cpu[s_idx] -= s_give
                    if contributed_ships >= need: break
                if contributed_ships > 0: waves_launched += 1
    if not all_entries: return _empty_entries(device, dtype), current_ships
    return concat_launch_entries(all_entries), available_ships


# ---------------------------------------------------------------------------
# Comet detection
# ---------------------------------------------------------------------------

def detect_comets(obs, prev_obs, threshold: float = 0.5) -> Tensor:
    P = int(obs.P)
    device = obs.device
    if prev_obs is None or P == 0:
        return torch.zeros(P, dtype=torch.bool, device=device)

    curr_pos = torch.stack([obs.x, obs.y], dim=1)
    prev_pos = torch.stack([prev_obs.x, prev_obs.y], dim=1)
    dist_moved = torch.norm(curr_pos - prev_pos, dim=1)

    is_moving = dist_moved > threshold
    is_neutral = obs.owner_abs < 0
    is_alive = obs.alive
    return is_moving & is_neutral & is_alive


# ---------------------------------------------------------------------------
# Dynamic adjustment
# ---------------------------------------------------------------------------

def _adjust_config(
    config: ProducerLiteConfig,
    *,
    obs,
    prod: Tensor,
    step: int,
    player_count: int,
) -> ProducerLiteConfig:
    pid = int(obs.player_id)
    strength = _owner_strength(obs, prod, int(player_count))
    if pid < 0 or pid >= int(player_count) or strength.numel() == 0:
        return config

    my = float(strength[pid].item())
    leader = float(strength.max().item())
    ratio = my / max(leader, 1e-6)

    # 1. Quadratic ROI Drop (من الكود 5 - الشراسة المتصاعدة)
    if ratio < 1.0:
        deficit = 1.0 - ratio
        roi_drop = 0.25 * (deficit ** 2)  # نزول تربيعي ناعم
        new_roi = max(1.10, float(config.roi_threshold) - roi_drop)

        remaining = TOTAL_STEPS - int(step)
        if remaining < 150 and ratio < 0.90:
            time_urgency = (150 - remaining) / 150.0
            new_roi = max(1.10, new_roi - 0.15 * time_urgency * deficit)
        config = replace(config, roi_threshold=new_roi)

    # 2. Horizon Adjustment (من الكود 3 - الهندسة)
    base_horizon = float(config.horizon)
    if ratio > 1.1:
        new_horizon = max(config.horizon_min, int(base_horizon * 0.7))
    elif ratio < 0.8:
        new_horizon = min(config.horizon_max, int(base_horizon * 1.3))
    else:
        new_horizon = int(base_horizon)
    config = replace(config, horizon=new_horizon)

    # 3. Wave Boosting (دمج 3 و 5)
    base_waves = int(config.max_waves_per_turn)
    if ratio < 0.70:
        base_waves = min(8, base_waves + 1)
    remaining = TOTAL_STEPS - int(step)
    if remaining < 100 and ratio < 0.95:
        base_waves = min(8, base_waves + 2) # شراسة مضاعفة في النهاية
    config = replace(config, max_waves_per_turn=base_waves)

    return config


# ---------------------------------------------------------------------------
# Movement helpers
# ---------------------------------------------------------------------------

def _movement_config(config: ProducerLiteConfig, *, player_count: int) -> MovementConfig:
    return MovementConfig(
        movement_horizon=int(config.horizon),
        drift_epsilon=1e-3,
        track_fleets=True,
        player_count=int(player_count),
        max_tracked_fleets=128,
    )


def cheap_enemy_pressure(obs, cache, *, horizon: float, player_id: int, available_budget: Tensor | None = None) -> Tensor:
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    if P == 0:
        return torch.zeros(P, dtype=dtype, device=device)
    d0 = cache.cross_dist[0].to(dtype)
    ships = (obs.ships if available_budget is None else available_budget).to(dtype)
    speeds = fleet_speed(ships.clamp(min=1e-6))
    reach_dist = (speeds.view(P, 1) * float(horizon)).clamp(min=1e-6)
    enemy = obs.alive & (obs.owner_abs >= 0) & (obs.owner_abs != int(player_id))
    eye = torch.eye(P, device=device, dtype=torch.bool)
    valid = enemy.view(P, 1) & obs.alive.view(1, P) & ~eye
    decay = (1.0 - d0 / reach_dist).clamp(min=0.0)
    contrib = torch.where(valid, ships.view(P, 1) * decay, torch.zeros_like(decay))
    return contrib.sum(dim=0)


# ---------------------------------------------------------------------------
# Late-game suppression
# ---------------------------------------------------------------------------

def _suppress_late_candidates(
    *,
    score: Tensor,
    obs,
    target_idx: Tensor,
    cand_tgt_short: Tensor,
    cand_is_def: Tensor,
    cand_eta: Tensor,
    step: int,
    player_id: int,
) -> Tensor:
    remaining = TOTAL_STEPS - int(step)
    if remaining > 120:
        return score
    P = int(obs.P)
    if P <= 0 or score.numel() == 0:
        return score
    device = score.device
    dtype = score.dtype
    pid = int(player_id)
    tgt_abs = target_idx[cand_tgt_short].clamp(0, P - 1)
    tgt_owner = obs.owner_abs.to(device=device)[tgt_abs].long()
    eta = (cand_eta[:, 0] if cand_eta.dim() > 1 else cand_eta).reshape(score.shape).to(device=device, dtype=dtype)

    is_neutral = tgt_owner < 0
    is_enemy = (tgt_owner >= 0) & (tgt_owner != pid) & (~cand_is_def)

    neutral_time = (remaining - eta) / max(1.0, 30.0)
    neutral_factor = torch.sigmoid(neutral_time * 0.5)
    score = torch.where(is_neutral, score * neutral_factor, score)

    enemy_time = (remaining - eta) / max(1.0, 20.0)
    enemy_factor = torch.sigmoid(enemy_time * 0.5)
    score = torch.where(is_enemy, score * enemy_factor, score)

    too_late = eta >= remaining
    return torch.where(too_late, torch.full_like(score, float("-inf")), score)


# ---------------------------------------------------------------------------
# Production snowball boost
# ---------------------------------------------------------------------------

def _apply_prod_snowball_boost(
    *,
    score: Tensor,
    obs,
    target_idx: Tensor,
    cand_tgt_short: Tensor,
    prod: Tensor,
    step: int,
    config: ProducerLiteConfig,
) -> Tensor:
    if int(step) > int(config.prod_rush_steps):
        return score

    P = int(obs.P)
    device = score.device
    dtype = score.dtype

    neutral_mask = obs.owner_abs < 0
    if not bool(neutral_mask.any()):
        return score

    prod_neutral = torch.where(neutral_mask & obs.alive, prod.to(dtype), torch.zeros(P, dtype=dtype, device=device))
    if int(prod_neutral.numel()) == 0:
        return score

    top_k = min(int(config.prod_rush_top_k), int(prod_neutral.numel()))
    top_vals = torch.topk(prod_neutral, top_k).values
    if top_vals.numel() == 0:
        return score
    threshold = float(top_vals[-1].item())

    tgt_abs = target_idx[cand_tgt_short].clamp(0, P - 1)
    tgt_prod = prod.to(dtype)[tgt_abs]
    tgt_neutral = (obs.owner_abs[tgt_abs] < 0)
    is_top_prod_neutral = tgt_neutral & (tgt_prod >= threshold - 1e-6)

    boost_factor = 1.0 / float(config.prod_rush_roi_discount)
    score = torch.where(is_top_prod_neutral.reshape(score.shape), score * boost_factor, score)
    return score


# ---------------------------------------------------------------------------
# Comet score boost
# ---------------------------------------------------------------------------

def _apply_comet_boost(
    *,
    score: Tensor,
    obs,
    target_idx: Tensor,
    cand_tgt_short: Tensor,
    comet_mask: Tensor,
    multiplier: float,
) -> Tensor:
    if comet_mask is None or not bool(comet_mask.any()):
        return score
    P = int(obs.P)
    device = score.device
    dtype = score.dtype
    tgt_abs = target_idx[cand_tgt_short].clamp(0, P - 1)
    is_comet_target = comet_mask[tgt_abs]
    boost = torch.where(is_comet_target, torch.tensor(multiplier, dtype=dtype, device=device),
                        torch.tensor(1.0, dtype=dtype, device=device))
    return score * boost.reshape(score.shape)


# ---------------------------------------------------------------------------
# NEW: Nearest / Furthest wave split
# Partitions the candidate pool into near (low-ETA) and far (high-ETA) buckets
# and allocates waves proportionally, so we always keep local consolidation
# happening while also reaching for high-value distant targets.
# ---------------------------------------------------------------------------

def _split_near_far_indices(
    *,
    score: Tensor,
    cand_valid: Tensor,
    cand_eta: Tensor,
    near_fraction: float,
) -> tuple[Tensor, Tensor]:
    """Return (near_mask, far_mask) over the candidate dimension."""
    device = score.device
    if cand_eta.dim() > 1:
        valid_eta = cand_eta[:, 0].reshape(score.shape)
    else:
        valid_eta = cand_eta.reshape(score.shape)
    valid_scores = torch.where(cand_valid, score, torch.full_like(score, float("-inf")))

    valid_eta_vals = valid_eta[cand_valid]
    if valid_eta_vals.numel() == 0:
        near = torch.zeros_like(cand_valid)
        far = torch.zeros_like(cand_valid)
        return near, far

    median_eta = float(valid_eta_vals.float().median().item())
    near = cand_valid & (valid_eta <= median_eta)
    far  = cand_valid & (valid_eta >  median_eta)
    return near, far


# ---------------------------------------------------------------------------
# Core planner – now with all spatial improvements
# ---------------------------------------------------------------------------



def _local_cluster_density(
    *,
    obs,
    cache,
    prod: Tensor,
) -> Tensor:
    """Calculates local production density for each planet.
    favors planets surrounded by high-production neighbors.
    """
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    if P <= 1:
        return torch.ones(P, dtype=dtype, device=device)

    # Use inverse distance weighting for neighborhood production
    d0 = cache.cross_dist[0].to(dtype).clamp(min=1.0)
    kernel = 1.0 / (d0 ** 2)
    # Zero out diagonal
    kernel.fill_diagonal_(0.0)

    # Production density: sum of neighbors' production weighted by distance
    neighbor_prod = (kernel @ prod.to(dtype).unsqueeze(1)).squeeze(1)
    # Normalize by the mean density to get a relative boost factor
    avg_density = neighbor_prod.mean().clamp(min=1e-6)
    density_boost = neighbor_prod / avg_density
    
    # Sigmoid squash to keep it in a reasonable range [0.8, 1.5]
    return 0.5 + 2.5 * torch.sigmoid(2.0 * (density_boost - 1.0))


def _cluster_dominance_intelligence(
    *,
    obs,
    cache,
    prod: Tensor,
    player_id: int,
) -> dict:
    """Calculates per-planet dominance intelligence.
    Returns:
        off_boost: Boost for offensive targets (favoring low dominance but high potential clusters)
        def_boost: Boost for defensive targets (favoring high dominance cluster protection)
    """
    P = int(obs.P)
    device = obs.device
    dtype = obs.ships.dtype
    if P <= 1:
        return {'off': torch.ones(P, dtype=dtype, device=device), 'def': torch.ones(P, dtype=dtype, device=device)}

    pid = int(player_id)
    owned = obs.owned & obs.alive
    enemy = obs.alive & (obs.owner_abs >= 0) & (obs.owner_abs != pid)
    
    d0 = cache.cross_dist[0].to(dtype).clamp(min=1.0)
    kernel = 1.0 / (d0 ** 2)
    kernel.fill_diagonal_(0.0)

    # total_cluster_prod: [P]
    total_cluster_prod = (kernel @ prod.to(dtype).unsqueeze(1)).squeeze(1)
    # owned_cluster_prod: [P]
    owned_cluster_prod = (kernel @ (prod.to(dtype) * owned.to(dtype)).unsqueeze(1)).squeeze(1)
    
    dominance = owned_cluster_prod / (total_cluster_prod + 1e-6)
    
    # Offensive Intelligence: Target areas where we have LOW dominance but there is HIGH total production
    # Range [1.0, 2.5]
    off_boost = 1.0 + 1.5 * (1.0 - dominance) * torch.sigmoid(total_cluster_prod / total_cluster_prod.mean().clamp(min=1e-6) - 1.0)
    
    # Defensive Intelligence: Prioritize areas where we have HIGH dominance (protecting the core)
    # Range [1.0, 2.0]
    def_boost = 1.0 + 1.0 * dominance
    
    return {'off': off_boost, 'def': def_boost}
def plan_lite_waves(
    *,
    movement: PlanetMovement,
    obs,
    obs_tensors: dict,
    cache,
    garrison_status,
    prod: Tensor,
    alive_by_step: Tensor,
    config: ProducerLiteConfig,
    player_count: int,
    memory,
    border_boost_vec: Tensor,
    intel_off: Tensor,
    available_budget: Tensor | None = None,
):
    P = obs.P
    device = obs.device
    dtype = obs.ships.dtype
    pid = int(obs.player_id)
    step = int(obs_tensors["step"].reshape(-1)[0].item())

    H_axis = int(garrison_status.ships.shape[-1])
    H = max(H_axis - 1, 0)
    K_eta = max(1, min(int(config.horizon), H))
    W = max(1, int(config.max_waves_per_turn))

    H_eff = torch.full((), float(H), dtype=dtype, device=device)

    ships = (obs.ships if available_budget is None else available_budget).to(dtype)
    prod_val = prod.to(dtype)

    # Source scoring with geometry + border boost
    centrality = _orbital_centrality(obs, cache)
    geo_w = float(config.geometry_weight)
    source_score = (
        (1.0 - geo_w) * (ships + 0.5 * prod_val * (ships / (ships + 1.0)))
        + geo_w * centrality * ships
    ) * border_boost_vec   # border planets rank higher as sources for defense routing
    source_mask = obs.owned & obs.alive & (ships >= float(config.min_ships_to_launch))
    source_score = torch.where(source_mask, source_score, torch.tensor(float("-inf"), device=device, dtype=dtype))
    S_cap = max(1, min(int(config.max_sources_per_lane), P))
    source_idx = torch.topk(source_score, min(S_cap, int(source_score.numel())), dim=0).indices
    source_exists = source_mask[source_idx]

    flow_baseline = precompute_flow_baseline(garrison_status, prod=movement.planet_prod, alive_by_step=alive_by_step)
    # Build target shortlist
    target_idx, target_exists = build_target_shortlist(
        obs, obs_tensors, garrison_status, cache,
        config=config, K_eta=K_eta, H=H, prod=prod, source_mask=source_mask,
    )

    # ---- Comet targets + KNN source supplementation ----
    comet_mask = getattr(memory, "comet_mask", None)
    if comet_mask is not None and bool(comet_mask.any()):
        comet_indices = comet_mask.nonzero(as_tuple=False).squeeze(1)
        all_targets = torch.cat([target_idx, comet_indices])
        unique_targets, _ = torch.unique(all_targets, return_inverse=True)
        target_idx = unique_targets
        target_exists = torch.ones(target_idx.shape[0], dtype=torch.bool, device=device)
        memory.current_comet_mask = comet_mask

        d0 = cache.cross_dist[0].to(dtype)
        owned_mask = obs.owned & obs.alive
        extra_sources = []
        for c in comet_indices.tolist():
            c = int(c)
            dists = d0[c, :]
            valid_sources = owned_mask & (torch.arange(P, device=device) != c)
            if not bool(valid_sources.any()):
                continue
            valid_dists = torch.where(valid_sources, dists, torch.full_like(dists, 1e9))
            k = min(2, int(valid_sources.sum().item()))
            if k > 0:
                nearest = torch.topk(-valid_dists, k).indices
                extra_sources.extend(nearest.tolist())
        if extra_sources:
            extra_src = torch.tensor(extra_sources, dtype=torch.long, device=device).unique()
            all_sources = torch.cat([source_idx, extra_src])
            unique_sources, _ = torch.unique(all_sources, return_inverse=True)
            source_idx = unique_sources
            source_exists = source_mask[source_idx]
    else:
        memory.current_comet_mask = None

    # ---- NEW: KNN source supplementation for ALL targets ----
    knn_extra = _knn_sources_for_targets(obs=obs, target_idx=target_idx, cache=cache, config=config)
    if knn_extra.numel() > 0:
        all_sources = torch.cat([source_idx, knn_extra])
        source_idx, _ = torch.unique(all_sources, return_inverse=True)
        source_exists = source_mask[source_idx]

    if not bool(target_exists.any()):
        return _empty_entries(device, dtype)


    # Sentinel: Bound counts to prevent DoS.
    S = min(64, int(source_idx.shape[0]))
    T = min(64, int(target_idx.shape[0]))
    if S < int(source_idx.shape[0]): source_idx = source_idx[:S]
    if T < int(target_idx.shape[0]):
        target_idx = target_idx[:T]
        target_exists = target_exists[:T]
    target_is_mine = obs.owned[target_idx.clamp(0, P - 1)]

    source_ships = obs.ships[source_idx.clamp(0, P - 1)].to(dtype)
    drain = safe_drain(
        garrison_status, source_idx=source_idx, source_ships=source_ships,
        H_eff=H_eff, player_id=pid,
    )

    eta_cap_val = torch.full((T,), float(K_eta), dtype=dtype, device=device)

    beta = float(config.reinforce_size_beta)
    enemy_mass = (
        cheap_enemy_pressure(obs, cache, horizon=float(K_eta), player_id=pid, available_budget=available_budget)
        if beta > 0.0 or bool(config.enable_regroup) else None
    )

    reinforcement = None
    if beta > 0.0:
        enemy_mass_t = enemy_mass[target_idx.clamp(0, P - 1)]
        k_arange = torch.arange(1, K_eta + 1, device=device, dtype=dtype)
        rho = reinforcement_timing_factor(
            k_arange, eta_free=float(config.reinforce_eta_free),
            eta_scale=float(config.reinforce_eta_scale),
        )
        reinforcement = beta * rho.view(1, K_eta) * enemy_mass_t.view(T, 1)

    floor = capture_floor(
        garrison_status, target_idx=target_idx, k_max=K_eta,
        capture_overhead=1.0, player_id=pid,
        reinforcement=reinforcement,
    )
    K = int(floor.shape[-1])

    all_cand_src = []
    all_cand_tgt_slot = []
    all_cand_tgt_short = []
    all_cand_send = []
    all_cand_angle = []
    all_cand_eta = []
    all_cand_active = []
    all_cand_valid = []
    all_cand_is_def = []
    all_score = []

    L = int(config.max_contributors_per_wave)

    for size_mult in config.size_multipliers:
        # Sizes for [S, T] pairs
        sizes_st = (drain.view(S, 1) * float(size_mult)).floor().clamp(min=1.0).expand(S, T)

        active_st = reachable_mask(
            movement, source_idx=source_idx, target_idx=target_idx,
            fleet_sizes=sizes_st.unsqueeze(-1), eta_cap=eta_cap_val,
        ).squeeze(-1)

        aim = intercept_angle(
            movement, source_idx.unsqueeze(1), target_idx.unsqueeze(0),
            sizes_st, active=active_st,
        )
        angle_st = aim["angle"]
        eta_st = aim["eta"]
        viable_st = aim["viable"] & (eta_st <= eta_cap_val.view(1, T))

        if True:
            # Traditional single-source candidates
            if K > 0:
                k_arr = (eta_st.clamp(min=1.0, max=float(K)).ceil().long() - 1).clamp(0, K - 1)
                floor_at_arr = floor.unsqueeze(0).expand(S, T, K).gather(-1, k_arr.unsqueeze(-1)).squeeze(-1)
            else:
                floor_at_arr = torch.ones(S, T, dtype=dtype, device=device)

            clears_floor = sizes_st >= floor_at_arr
            src_neq_tgt = source_idx.view(S, 1) != target_idx.view(1, T)
            valid_st = viable_st & clears_floor & (sizes_st >= float(config.min_ships_to_launch)) & src_neq_tgt

            C = S * T
            c_src = source_idx.view(S, 1).expand(S, T).reshape(C, 1)
            c_tgt_slot = target_idx.view(1, T).expand(S, T).reshape(C)
            c_tgt_short = torch.arange(T, device=device).view(1, T).expand(S, T).reshape(C)
            c_send = torch.where(valid_st, sizes_st, torch.zeros_like(sizes_st)).reshape(C, 1)
            c_angle = angle_st.reshape(C, 1)
            c_eta = torch.where(valid_st, eta_st, torch.ones_like(eta_st)).reshape(C, 1)
            c_active = valid_st.reshape(C, 1)
            c_valid = valid_st.reshape(C)

            # Score them
            launches = make_launch_set(
                source_slots=c_src, target_slots=c_tgt_slot.unsqueeze(-1),
                ships=c_send, eta=c_eta, valid=c_active & c_valid.unsqueeze(-1), player_id=pid
            )
            c_score = score_candidates(garrison_status, prod=prod, alive_by_step=alive_by_step,
                                       player_count=int(player_count), launches=launches, player_id=pid, baseline=flow_baseline)

            all_cand_src.append(c_src)
            all_cand_tgt_slot.append(c_tgt_slot)
            all_cand_tgt_short.append(c_tgt_short)
            all_cand_send.append(c_send)
            all_cand_angle.append(c_angle)
            all_cand_eta.append(c_eta)
            all_cand_active.append(c_active)
            all_cand_valid.append(c_valid)
            all_cand_is_def.append(target_is_mine[c_tgt_short])
            all_score.append(c_score)

        if L > 1:
            # Pulse: Fully Vectorized Multi-source synchronization across [T, K_eta]
            turns_st = eta_st.ceil().long().clamp(1, K_eta)
            k_range = torch.arange(1, K_eta + 1, device=device).view(1, 1, K_eta)
            mask_tks = (viable_st.unsqueeze(-1) & (turns_st.unsqueeze(-1) == k_range)).permute(1, 2, 0)
            if mask_tks.any():
                scores_tks = source_score[source_idx].view(1, 1, S).expand(T, K_eta, S)
                ranked_scores = torch.where(mask_tks, scores_tks, torch.tensor(float("-inf"), device=device))
                top_k = torch.topk(ranked_scores, L, dim=2, sorted=True)
                top_val, top_indices = top_k.values, top_k.indices
                sizes_ts = sizes_st.t()
                ships_tkl = sizes_ts.unsqueeze(1).expand(T, K_eta, S).gather(2, top_indices)
                valid_tkl = top_val > float("-inf")
                total_ships_tk = (ships_tkl * valid_tkl.float()).sum(dim=2)
                target_floor_tk = floor[:, :K_eta]
                tk_mask = (total_ships_tk >= target_floor_tk) & (total_ships_tk >= float(config.min_ships_to_launch))
                if tk_mask.any():
                    t_valid, k_valid = tk_mask.nonzero(as_tuple=True)
                    n_sync = t_valid.shape[0]
                    c_src = source_idx[top_indices[t_valid, k_valid]]
                    c_send = ships_tkl[t_valid, k_valid]
                    c_angle = angle_st.t().unsqueeze(1).expand(T, K_eta, S).gather(2, top_indices)[t_valid, k_valid]
                    c_eta = eta_st.t().unsqueeze(1).expand(T, K_eta, S).gather(2, top_indices)[t_valid, k_valid]
                    c_active = valid_tkl[t_valid, k_valid]
                    c_tgt_slot = target_idx[t_valid]
                    c_tgt_short, c_valid = t_valid, torch.ones(n_sync, dtype=torch.bool, device=device)
                    launches = make_launch_set(source_slots=c_src, target_slots=c_tgt_slot.unsqueeze(-1).expand(-1, L), ships=c_send, eta=c_eta, valid=c_active & c_valid.unsqueeze(-1), player_id=pid)
                    c_score = score_candidates(garrison_status, prod=prod, alive_by_step=alive_by_step, player_count=int(player_count), launches=launches, player_id=pid, baseline=flow_baseline)
                    all_cand_src.append(c_src); all_cand_tgt_slot.append(c_tgt_slot); all_cand_tgt_short.append(c_tgt_short)
                    all_cand_send.append(c_send); all_cand_angle.append(c_angle); all_cand_eta.append(c_eta)
                    all_cand_active.append(c_active); all_cand_valid.append(c_valid)
                    all_cand_is_def.append(target_is_mine[c_tgt_short]); all_score.append(c_score)




    if not all_score:
        return _empty_entries(device, dtype)

    # Pad all candidates to max L contributors to allow concatenation
    L_max = max([c.shape[1] for c in all_cand_src])
    for i in range(len(all_cand_src)):
        curr_L = all_cand_src[i].shape[1]
        if curr_L < L_max:
            pad_size = L_max - curr_L
            all_cand_src[i] = torch.cat([all_cand_src[i], torch.zeros((all_cand_src[i].shape[0], pad_size), dtype=torch.long, device=device)], dim=1)
            all_cand_send[i] = torch.cat([all_cand_send[i], torch.zeros((all_cand_send[i].shape[0], pad_size), dtype=dtype, device=device)], dim=1)
            all_cand_angle[i] = torch.cat([all_cand_angle[i], torch.zeros((all_cand_angle[i].shape[0], pad_size), dtype=dtype, device=device)], dim=1)
            all_cand_eta[i] = torch.cat([all_cand_eta[i], torch.ones((all_cand_eta[i].shape[0], pad_size), dtype=dtype, device=device)], dim=1)
            all_cand_active[i] = torch.cat([all_cand_active[i], torch.zeros((all_cand_active[i].shape[0], pad_size), dtype=torch.bool, device=device)], dim=1)

    cand_src = torch.cat(all_cand_src, dim=0)

    cand_tgt_slot = torch.cat(all_cand_tgt_slot, dim=0)
    cand_tgt_short = torch.cat(all_cand_tgt_short, dim=0)
    cand_send = torch.cat(all_cand_send, dim=0)
    cand_angle = torch.cat(all_cand_angle, dim=0)
    cand_eta = torch.cat(all_cand_eta, dim=0)
    cand_active = torch.cat(all_cand_active, dim=0)
    cand_valid = torch.cat(all_cand_valid, dim=0)
    cand_is_def = torch.cat(all_cand_is_def, dim=0)
    score = torch.cat(all_score, dim=0)

    # ---- NEW: Adaptive distance penalty ----
    dist_matrix = cache.cross_dist[0].to(dtype)
    # For multi-source, use the distance from the FIRST contributor (usually the strongest)
    cand_src_abs = cand_src[:, 0]
    cand_tgt_abs = cand_tgt_slot
    dist = dist_matrix[cand_src_abs, cand_tgt_abs]
    distance_scale = _adaptive_distance_scale(dist, cache, obs)
    score = score * distance_scale.reshape(score.shape)

    # ---- NEW: Shrinking ring conquest multiplier ----
    ring_mult = _ring_conquest_multiplier(
        obs=obs, target_idx=target_idx, cache=cache, config=config, step=step,
    )
    score = score * ring_mult[cand_tgt_short].reshape(score.shape)

    # ---- NEW: Committed-fleet penalty ----
    committed_mult = _committed_fleet_penalty_mask(
        obs=obs, target_idx=target_idx, memory=memory, config=config,
    )
    

    # ---- NEW: Local Cluster Density Boost ----
    score = score * intel_off[target_idx[cand_tgt_short]].reshape(score.shape)

    # ---- NEW: Enemy Density Weighting (Denial Value) ----
    enemy_mask = obs.alive & (obs.owner_abs >= 0) & (obs.owner_abs != pid)
    if enemy_mask.any():
        d0 = cache.cross_dist[0].to(dtype).clamp(min=1.0)
        kernel = 1.0 / (d0 ** 2)
        enemy_nearby_prod = (kernel @ (prod.to(dtype) * enemy_mask.to(dtype)).unsqueeze(1)).squeeze(1)
        denial_boost = 1.0 + 0.5 * torch.sigmoid(enemy_nearby_prod / enemy_nearby_prod.mean().clamp(min=1e-6) - 1.0)
        score = score * denial_boost[target_idx[cand_tgt_short]].reshape(score.shape)
    score = score * committed_mult[cand_tgt_short].reshape(score.shape)

    # ---- Strategic alignment (cosine similarity toward enemy centre) ----
    own_mask = obs.owned & obs.alive
    if own_mask.any():
        pos = torch.stack([obs.x, obs.y], dim=1)
        weights = (obs.ships + 0.5 * prod_val).to(dtype)
        centre_own = (pos * own_mask.unsqueeze(-1) * weights.unsqueeze(-1)).sum(dim=0) / (weights[own_mask].sum() + 1e-6)
        enemy_mask = obs.alive & (obs.owner_abs >= 0) & (obs.owner_abs != pid)
        if enemy_mask.any():
            centre_enemy = (pos * enemy_mask.unsqueeze(-1) * weights.unsqueeze(-1)).sum(dim=0) / (weights[enemy_mask].sum() + 1e-6)
            strategic_vec = centre_enemy - centre_own
            strategic_vec = strategic_vec / (strategic_vec.norm() + 1e-6)
            src_pos = pos[cand_src_abs]
            tgt_pos = pos[cand_tgt_abs]
            candidate_vec = tgt_pos - src_pos
            candidate_vec_norm = candidate_vec / (candidate_vec.norm(dim=1, keepdim=True) + 1e-6)
            cos_sim = (candidate_vec_norm * strategic_vec).sum(dim=1)
            align_weight = 1.0 + 0.5 * (cos_sim + 1.0)
            score = score * align_weight.reshape(score.shape)



    # ---- NEW: Multi-source vulnerability penalty ----
    # Multi-source strikes are powerful but leave multiple sources vulnerable.
    # Apply a penalty based on the number of active contributors.
    n_active = cand_active.float().sum(dim=1)
    # Give a small bonus for synchronization to encourage it when it matters,
    # but also account for cost.
    # v133: Neutral sync is good, Enemy sync is better.
    # We'll use a small penalty for multiple sources to avoid over-committing.
    multi_vulnerability = 1.0 - (n_active - 1) * 0.10
    score = score * multi_vulnerability.reshape(score.shape)

    # Late-game suppression
    score = _suppress_late_candidates(
        score=score, obs=obs, target_idx=target_idx,
        cand_tgt_short=cand_tgt_short, cand_is_def=cand_is_def,
        cand_eta=cand_eta, step=int(step), player_id=pid,
    )

    # Production snowball boost
    score = _apply_prod_snowball_boost(
        score=score, obs=obs, target_idx=target_idx,
        cand_tgt_short=cand_tgt_short, prod=prod,
        step=int(step), config=config,
    )

    # Comet boost
    if memory.current_comet_mask is not None:
        score = _apply_comet_boost(
            score=score, obs=obs, target_idx=target_idx,
            cand_tgt_short=cand_tgt_short,
            comet_mask=memory.current_comet_mask,
            multiplier=float(config.comet_score_multiplier),
        )

    score = torch.where(cand_valid, score, torch.full_like(score, float("-inf")))

    # ---- NEW: Nearest / Furthest wave split ----
    # Allocate near_wave_fraction of W to nearest targets, rest to furthest.
    W_near = max(1, round(W * float(config.near_wave_fraction)))
    W_far  = max(1, W - W_near)

    near_mask, far_mask = _split_near_far_indices(
        score=score, cand_valid=cand_valid,
        cand_eta=cand_eta.squeeze(-1) if cand_eta.dim() > 1 else cand_eta,
        near_fraction=float(config.near_wave_fraction),
    )

    score_near = torch.where(near_mask, score, torch.full_like(score, float("-inf")))
    score_far  = torch.where(far_mask,  score, torch.full_like(score, float("-inf")))

    near_entries, near_leftover = _greedy_select(
        P=P, W=W_near, device=device, dtype=dtype, score=score_near,
        cand_src=cand_src, cand_send=cand_send, cand_angle=cand_angle, cand_eta=cand_eta,
        cand_active=cand_active, cand_tgt_slot=cand_tgt_slot, cand_tgt_short=cand_tgt_short,
        cand_is_def=cand_is_def, source_budget=obs.ships.to(dtype).clone(),
        target_exists=target_exists, roi_threshold=float(config.roi_threshold),
    )
    # far_leftover is the budget after near greedy pass
    far_entries, far_leftover = _greedy_select(
        P=P, W=W_far, device=device, dtype=dtype, score=score_far,
        cand_src=cand_src, cand_send=cand_send, cand_angle=cand_angle, cand_eta=cand_eta,
        cand_active=cand_active, cand_tgt_slot=cand_tgt_slot, cand_tgt_short=cand_tgt_short,
        cand_is_def=cand_is_def, source_budget=near_leftover,
        target_exists=target_exists, roi_threshold=float(config.roi_threshold),
    )
    wave_entries = concat_launch_entries([near_entries, far_entries])
    # Merge leftovers for regroup
    leftover = far_leftover   # primary leftover for regroup pass

    # ---- NEW: Track committed targets in memory ----
    # Collect target planet ids from this turn's launches so next turn we
    # can apply the committed-fleet penalty to avoid double-sending.
    try:
        if hasattr(wave_entries, "target_slots") and wave_entries.target_slots.numel() > 0:
            committed_this_turn = wave_entries.target_slots.reshape(-1).unique()
            memory.committed_targets = committed_this_turn
        else:
            memory.committed_targets = torch.zeros(0, dtype=torch.long, device=device)
    except Exception:
        memory.committed_targets = torch.zeros(0, dtype=torch.long, device=device)

    if not bool(config.enable_regroup):
        return wave_entries

    regroup_entries = _plan_regroup(
        movement=movement, obs=obs, obs_tensors=obs_tensors, garrison_status=garrison_status,
        leftover=leftover, original_ships=obs.ships.to(dtype), pressure=enemy_mass,
        config=config, H=H,
    )
    return concat_launch_entries([wave_entries, regroup_entries])


# ---------------------------------------------------------------------------
# Turn pipeline – runs defense (with border boost), comet detection, offense
# ---------------------------------------------------------------------------

def run_turn(obs_tensors: dict, *, config: ProducerLiteConfig, player_count: int, memory) -> dict:
    device = obs_tensors["planets"].device
    obs = parse_obs(obs_tensors)
    P = obs.P
    if P == 0:
        return empty_action_row(device)

    movement = ensure_planet_movement(
        obs_tensors=obs_tensors,
        expected_cfg=_movement_config(config, player_count=int(player_count)),
        cached_movement=getattr(memory, "movement", None),
    )
    memory.movement = movement
    step = int(obs_tensors["step"].reshape(-1)[0].item())

    config = _adjust_config(
        config, obs=obs, prod=movement.planet_prod, step=step, player_count=int(player_count)
    )

    cache = build_distance_cache(movement, max_k=int(config.horizon))
    H = int(config.horizon)
    status = movement.garrison_status(max_horizon=H)
    alive_by_step = movement.alive_by_step[: H + 1]

    # ---- NEW: Compute border boost once, share across defense + offense ----
    border_boost_vec = _border_defense_boost(obs=obs, cache=cache, config=config)
    intel = _cluster_dominance_intelligence(obs=obs, cache=cache, prod=movement.planet_prod, player_id=int(obs.player_id))

    # Proactive defense (now border-aware)
    defense_entries, remaining_budget = _build_defense_entries(
        status=status, obs=obs, cache=cache, prod=movement.planet_prod,
        config=config, player_count=int(player_count),
        border_boost_vec=border_boost_vec,
        intel_def=intel["def"],
    )

    # Comet detection
    prev_obs = getattr(memory, "prev_obs", None)
    comet_mask = detect_comets(obs, prev_obs, threshold=float(config.comet_movement_threshold))
    memory.prev_obs = obs
    memory.comet_mask = comet_mask

    # Offensive wave planning
    entries = plan_lite_waves(
        movement=movement, obs=obs, obs_tensors=obs_tensors, cache=cache,
        garrison_status=status, prod=movement.planet_prod,
        alive_by_step=alive_by_step, config=config, player_count=int(player_count),
        memory=memory,
        border_boost_vec=border_boost_vec,
        intel_off=intel["off"],
        available_budget=remaining_budget,
    )

    # Merge defense + offense
    entries = concat_launch_entries([defense_entries, entries])
    entries = disambiguate_duplicate_launches(entries)

    launches = infer_planned_launches_from_entries(
        obs_tensors=obs_tensors, movement=movement, entries=entries, player_id=int(obs.player_id),
    )
    apply_private_planned_launches(
        movement=movement, launches=launches, owner_id=int(obs.player_id),
        obs_tensors=obs_tensors,
    )
    planet_ids = obs_tensors["planets"][..., 0].long()
    return entries_to_sparse_payload(entries, planet_ids=planet_ids)


# ---------------------------------------------------------------------------
# Mode presets
# ---------------------------------------------------------------------------

CONFIG_2P = replace(
    ProducerLiteConfig(),
    roi_threshold=1.10,
    max_offensive_targets=16,
    max_waves_per_turn=8,
    size_multipliers=(1.0,),
    max_contributors_per_wave=1,
)

CONFIG_3P = replace(
    ProducerLiteConfig(),
    horizon=15,
    max_sources_per_lane=8,
    max_offensive_targets=12,
    max_defensive_targets=5,
    max_waves_per_turn=6,
    roi_threshold=1.30,
    prod_rush_steps=100,
    near_wave_fraction=0.60,
    ring_inner_boost=2.0,
    size_multipliers=(0.7, 1.0),
    max_contributors_per_wave=2,
    reinforce_size_beta=2.2,
)

CONFIG_4P = replace(
    ProducerLiteConfig(),
    horizon=13,
    roi_threshold=1.25,
    max_sources_per_lane=7,
    max_offensive_targets=12,
    max_defensive_targets=4,
    max_waves_per_turn=6,
    max_regroup_time=6.0,
    max_regroup_targets_per_source=8,
    prod_rush_steps=80,
    geometry_weight=0.45,
    near_wave_fraction=0.55,
    ring_inner_boost=2.0,
    ring_outer_penalty=0.5,
    knn_sources_per_target=2,
    border_boost=1.8,
    size_multipliers=(0.6, 1.0),
    max_contributors_per_wave=3,
    reinforce_size_beta=2.2,
)


def _config_for(player_count: int) -> ProducerLiteConfig:
    pc = int(player_count)
    if pc >= 4:
        return CONFIG_4P
    elif pc == 3:
        return CONFIG_3P
    return CONFIG_2P


# ---------------------------------------------------------------------------
# Runtime & entry point
# ---------------------------------------------------------------------------

class ProducerLiteMemory:
    def __init__(self) -> None:
        self.movement = None
        self.cached_player_count: int | None = None
        self.last_sparse_action_row: dict | None = None
        # comet detection state
        self.prev_obs = None
        self.comet_mask = None
        self.current_comet_mask = None
        # NEW: committed-fleet tracking
        self.committed_targets = None

    def reset(self) -> None:
        self.movement = None
        self.cached_player_count = None
        self.last_sparse_action_row = None
        self.prev_obs = None
        self.comet_mask = None
        self.current_comet_mask = None
        self.committed_targets = None


class ProducerLiteRuntime:
    def __init__(self, memory: ProducerLiteMemory | None = None) -> None:
        self.memory = memory if memory is not None else ProducerLiteMemory()

    def reset(self) -> None:
        self.memory.reset()

    def tensor_action(self, obs_tensors: dict):
        mem = self.memory
        if bool((obs_tensors["step"] == 0).all()):
            mem.cached_player_count = None
            mem.prev_obs = None
            mem.comet_mask = None
            mem.current_comet_mask = None
            mem.committed_targets = None
        if mem.cached_player_count is None:
            mem.cached_player_count = largest_initial_player_count(obs_tensors)
        config = _config_for(mem.cached_player_count)
        row = run_turn(
            obs_tensors, config=config,
            player_count=int(mem.cached_player_count), memory=mem,
        )
        mem.last_sparse_action_row = row
        return row


_RUNTIME = ProducerLiteRuntime()


def agent(obs):
    player = obs.get("player", 0) if isinstance(obs, dict) else obs.player
    player_id = int(player)
    obs_tensors = single_obs_to_tensor(obs, player_id=player_id)
    with torch.no_grad():
        sparse_row = _RUNTIME.tensor_action(obs_tensors)
    return sparse_action_row_to_moves(sparse_row, obs, player_id=player_id)
